#include "ListaGuloso.h"
#include <iostream>

using namespace std;

ListaGuloso::ListaGuloso()
{
    //ctor
}

ListaGuloso::~ListaGuloso()
{
    //dtor
}

void ListaGuloso::insereNo(No* id)
{
    NoListaGuloso* aux = new NoListaGuloso(id);

    if(this->primeiroNo == nullptr)
    {
        primeiroNo=aux;
        ultimoNo=aux;
    }
    else
    {
        ultimoNo->setProx(aux);
        aux->setAnt(ultimoNo);
        ultimoNo = aux;
    }
    tam++;
}

No* ListaGuloso::removeNo(int indice)
{
    if(indice > tam)
    {
        return nullptr;
    }
    else
    {
        NoListaGuloso* aux = primeiroNo;
        No* retorno;
        for(int i=0; i<indice; i++)
        {
            aux = aux->getProx();
        }
        retorno = aux->getPonteiro();
        delete aux;
        return retorno;
    }
}



NoListaGuloso* ListaGuloso::buscaNo(int id)
{
    NoListaGuloso* aux = this->primeiroNo;
    if(aux == nullptr)
        return nullptr;

    while(aux->getId() != id && aux->getProx()!=nullptr)
        aux = aux->getProx();

    if(aux->getId() == id)
        return aux;
    else
        return nullptr;
}

void ListaGuloso::reorganiza(NoListaGuloso* no, NoListaGuloso* ant, NoListaGuloso* prox)
{
    no->deslinka();
    no->setAnt(ant);
    no->setProx(prox);
    ant->setProx(no);
    prox->setAnt(no);
}


int ListaGuloso::getTam()
{
    return tam;
}

NoListaGuloso* ListaGuloso::getPrimeiroNo()
{
    return primeiroNo;
}

NoListaGuloso* ListaGuloso::getUltimoNo()
{
    return ultimoNo;
}
