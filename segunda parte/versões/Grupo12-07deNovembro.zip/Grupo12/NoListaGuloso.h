#ifndef NOLISTAGULOSO_H
#define NOLISTAGULOSO_H
#include "No.h"

using namespace std;

class NoListaGuloso
{
    public:
        NoListaGuloso(No* id);
        ~NoListaGuloso();
        void setProx(NoListaGuloso* prox);
        void setAnt(NoListaGuloso* prox);
        NoListaGuloso* getProx();
        NoListaGuloso* getAnt();
        int getId();
        float getCoeficiente();
        No* getPonteiro();
        void decrementaGrau();
        void deslinka();

    private:
        No* ponteiro;
        NoListaGuloso* proximo;
        NoListaGuloso* anterior;
        int id;
        int grau;
        float peso;
        float coeficiente;
};
#endif
