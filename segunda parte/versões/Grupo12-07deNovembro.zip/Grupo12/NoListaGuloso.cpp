#include "NoListaGuloso.h"
#include <iostream>

using namespace std;

NoListaGuloso::NoListaGuloso(No* id)
{
    ponteiro = id;
    this->setAnt(nullptr);
    this->setProx(nullptr);
    this->id = id->getId();
    peso = id->getPeso();
    grau = id->getGrauEntrada();
    coeficiente = peso/grau;
}

NoListaGuloso::~NoListaGuloso()
{
    if(this->getProx()!=nullptr)
    {
        this->proximo->setAnt(this->anterior);
    }

    if(this->anterior!=nullptr)
    {
        this->anterior->setProx(this->proximo);
    }
}

void NoListaGuloso::setProx(NoListaGuloso* prox)
{
    this->proximo = prox;
}

void NoListaGuloso::setAnt(NoListaGuloso* ant)
{
    this->anterior = ant;
}

NoListaGuloso* NoListaGuloso::getProx()
{
    return proximo;
}

NoListaGuloso* NoListaGuloso::getAnt()
{
    return anterior;
}


int NoListaGuloso::getId()
{
    return id;
}

float NoListaGuloso::getCoeficiente()
{
    return coeficiente;
}


No* NoListaGuloso::getPonteiro()
{
    return ponteiro;
}

void NoListaGuloso::decrementaGrau()
{
    cout << "..." <<endl;
    cout << grau;
    cout << "kim petras" <<endl;
    coeficiente = peso/grau;
    cout << ";)" <<endl;
}

void NoListaGuloso::deslinka()
{
    if(proximo != nullptr)
        proximo->setAnt(this->anterior);
    if(anterior != nullptr)
        anterior->setProx(this->proximo);
}
