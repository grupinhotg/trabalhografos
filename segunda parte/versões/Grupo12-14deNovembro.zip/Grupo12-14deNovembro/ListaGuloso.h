#ifndef LISTAGULOSO_H
#define LISTAGULOSO_H
#include "NoListaGuloso.h"
#include "No.h"

using namespace std;

class ListaGuloso
{
    public:
        ListaGuloso();
        ~ListaGuloso();
        void insereNo(No* id);
        No* removeNo(int indice);
        NoListaGuloso* buscaNo(int id);
        void reorganiza(NoListaGuloso* no, NoListaGuloso* ant, NoListaGuloso* prox);
        int getTam();
        NoListaGuloso* getPrimeiroNo();
        NoListaGuloso* getUltimoNo();
        void imprimeLista();

    private:
        NoListaGuloso* primeiroNo;
        NoListaGuloso* ultimoNo;
        int tam;
};

#endif // LISTAGULOSO_H
