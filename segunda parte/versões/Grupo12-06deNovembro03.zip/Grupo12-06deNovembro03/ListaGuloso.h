#ifndef LISTAGULOSO_H
#define LISTAGULOSO_H
#include "NoListaGuloso.h"
#include "No.h"


class ListaGuloso
{
    public:
        ListaGuloso();
        ~ListaGuloso();
        void insereNo(No* id);

    private:
        NoListaGuloso* primeiroNo;
        NoListaGuloso* ultimoNo;
};

#endif // LISTAGULOSO_H
