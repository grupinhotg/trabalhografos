#include "ListaGuloso.h"

ListaGuloso::ListaGuloso()
{
    //ctor
}

ListaGuloso::~ListaGuloso()
{
    //dtor
}

void ListaGuloso::insereNo(No* id)
{
    NoListaGuloso* aux = new NoListaGuloso(id);

    if(this->primeiroNo == nullptr) // se o grafo estiver vazio, seta o primeiro e o ultimo nó como o novo nó criado
    {
        primeiroNo=aux;
        ultimoNo=aux;
    }
    else                            // se o grafo já tiver nós
    {
        ultimoNo->setProx(aux);   //seta o próx do ultimo nó para o novo
        aux->setAnt(ultimoNo);
        ultimoNo = aux;             //seta o ultimo nó como o novo nó criado
    }
}
