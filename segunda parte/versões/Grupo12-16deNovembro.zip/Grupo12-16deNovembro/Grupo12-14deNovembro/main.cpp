#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <utility>
#include <tuple>
#include <iomanip>
#include <stdlib.h>
#include <chrono>
#include "Grafo.h"
#include "No.h"

using namespace std;

Grafo* leituraInstancia(ifstream& arquivoEntrada)
{
    int ordem;
    int peso;
    string linha;
    arquivoEntrada >> linha;
    arquivoEntrada >> ordem;

    Grafo* G = new Grafo(ordem, 0, 0, 1);

    for(int i = 0; i<(ordem+3); i++)
    {
        getline(arquivoEntrada, linha);
    }
    for(int i=0;i<ordem;i++)
    {
        getline(arquivoEntrada, linha);
        peso = stoi(linha);
        G->insereNo(i, peso);
    }
    getline(arquivoEntrada, linha);
    int nlin =0;

    while((!arquivoEntrada.eof())&& (nlin!=ordem))
    {
        int ncol = -1;
        getline(arquivoEntrada, linha);
        for(int i = 0; i <(2*ordem); i++)
        {
            if(ncol >= nlin)
            {
                break;
            }
            if(linha !="" && (linha.at(i) == '1' || linha.at(i) == '0'))
            {
                ncol++;
            }
            if(linha != "" && linha.at(i) == '1' && ncol!=nlin)
            {
                G->insereAresta(nlin, ncol, 0);
            }
        }
        nlin++;
    }

    return G;
}

//

int main(int argc, char const *argv[])
{
    ifstream arquivoEntrada;
    bool dir, areP, noP;
    arquivoEntrada.open(argv[1]);

    Grafo* G;

    if(arquivoEntrada.is_open())
    {
        G = leituraInstancia(arquivoEntrada);
    }
    else
    {
        cout << "Nao e possivel abrir: " << argv[1];
        return 0;
    }



//    G->imprimeGrafo();
//   G->algoritmoGuloso();
    G->algoritmoGulosoRand(1000, 0.1);

    return 0;
}
