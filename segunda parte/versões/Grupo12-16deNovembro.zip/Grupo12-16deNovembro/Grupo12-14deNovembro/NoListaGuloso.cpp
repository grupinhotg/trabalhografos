#include "NoListaGuloso.h"
#include <iostream>

using namespace std;

NoListaGuloso::NoListaGuloso(No* id)
{
    ponteiro = id;
    this->setAnt(nullptr);
    this->setProx(nullptr);
    this->id = id->getId();
    peso = id->getPeso();
    grau = id->getGrauEntrada();
    coeficiente = peso/grau;
}

NoListaGuloso::~NoListaGuloso()
{
    if(this->getProx()!=nullptr)
    {
        this->proximo->setAnt(this->anterior);
    }
    if(this->anterior!=nullptr)
    {
        this->anterior->setProx(this->proximo);
    }
}

void NoListaGuloso::setProx(NoListaGuloso* prox)
{
    this->proximo = prox;
}

void NoListaGuloso::setAnt(NoListaGuloso* ant)
{
    this->anterior = ant;
}

NoListaGuloso* NoListaGuloso::getProx()
{
    return proximo;
}

NoListaGuloso* NoListaGuloso::getAnt()
{
    return anterior;
}


int NoListaGuloso::getId()
{
    return id;
}

int NoListaGuloso::getGrau()
{
    return grau;
}

float NoListaGuloso::getPeso()
{
    return peso;
}



float NoListaGuloso::getCoeficiente()
{
    return coeficiente;
}


No* NoListaGuloso::getPonteiro()
{
    return ponteiro;
}

void NoListaGuloso::decrementaGrau()
{
    grau--;
    if(grau!=0)
        coeficiente = (peso/grau);
    else
        coeficiente = 0;
}

void NoListaGuloso::deslinka()
{
    if(proximo != nullptr)
    {
        proximo->setAnt(anterior);
    }
    if(anterior != nullptr)
    {
        anterior->setProx(proximo);
    }
    proximo=nullptr;
    anterior=nullptr;
}
