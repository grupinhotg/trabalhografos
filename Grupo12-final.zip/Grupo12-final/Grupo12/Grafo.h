#ifndef GRAFO_H
#define GRAFO_H
#include "No.h"
#include <fstream>
#include <stack>
#include <list>

using namespace std;

class Grafo
{
    public:
        Grafo(int ordem, bool direcionado, bool arestaComPeso, bool noComPeso);     // construtor
        ~Grafo();                                                                   // destrutor
        int getOrdem();                                                             // retorna ordem do grafo
        int getNumAresta();                                                         // retorna numero de arestas
        bool getDirecionado();                                                      // verifica se eh direcionado
        bool getArestaComPeso();                                                    // verifica se eh ponderado nas arestas
        bool getNoComPeso();                                                        // verifica se eh ponderado nos nos
        No* getPrimeiroNo();                                                        // retorna primeiro no
        No* getUltimoNo();                                                          // retorna ultimo no
        void insereNo(int id);                                                      // insere no
        void insereAresta(int id, int idAlvo, float peso);                          // insere aresta
        void removeNo (int id);                                                     // remove no
        void procuraNo (int id);                                                    // procura no
        No* getNo(int id);                                                          // retorna no
        bool buscaEmProfundidade (int idInicial, int idAlvo);                       // busca em profundidade
        void larguraEmProfundidade (ofstream& arquivo_saida);                       // largura em profundidade
        Grafo* getComplemento();                                                    // retorna complemento
        Grafo* getSubjacente();                                                     // retorna subjacente
        bool possuiCircuito();                                                      // verifica se possui circuito
        bool grafoConexo();                                                         // verifica se o grafo eh conexo
        float** floydMarshall();                                                    // funcao floyd marshall
        float* dijkstra(int id);                                                    // funcao dijkstra
        void imprimeGrafo();                                                        // imprime o grafo na tela

    private:
        int ordem;
        int numAresta;
        bool direcionado;
        bool arestaComPeso;
        bool noComPeso;
        No* primeiroNo;
        No* ultimoNo;

        // funcoes auxiliares
};

#endif // GRAFO_H
