#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <utility>
#include <tuple>
#include <iomanip>
#include <stdlib.h>
#include <chrono>
#include "Grafo.h"
#include "No.h"

using namespace std;

Grafo* leituraInstancia(ifstream& arquivoEntrada, bool direcionado, bool arestaComPeso, bool noComPeso)
{
    //Vari�veis para auxiliar na cria��o dos n�s no Grafo
    int id;
    int idAlvo;
    int ordem;
    float peso;

    //Pegando a ordem do grafo
    arquivoEntrada >> ordem;

    //Criando objeto grafo
    Grafo* G = new Grafo(ordem, direcionado, arestaComPeso, noComPeso);

    //Leitura de arquivo
    if(!G->getArestaComPeso() && !G->getNoComPeso())             /// aresta sem peso e no sem peso
    {
        while(arquivoEntrada >> id >> idAlvo)
            G->insereAresta(id, idAlvo, 0);         // insere arestas sem peso
    }
    else if(G->getArestaComPeso() && !G->getNoComPeso())         /// aresta com peso e no sem peso
    {
        float peso;
        while(arquivoEntrada >> id >> idAlvo >> peso)
            G->insereAresta(id, idAlvo, peso);      // insere arestas com peso
    }

/*
    else if(G->getNoComPeso() && !G->getArestaComPeso())          /// no com peso e aresta sem peso
    {
        float idPeso, idAlvoPeso;
        while(arquivoEntrada >> id >> idPeso >> idAlvo >> idAlvoPeso)
        {
            G->insereAresta(id, idAlvo, 0);         // insere aresta sem peso
            G->getNo(id)->setPeso(idPeso);          // seta no inicial com peso
            G->getNo(idAlvo)->setPeso(idAlvoPeso);  // seta no alvo com peso
        }
    }
    else if(G->getNoComPeso() && G->getArestaComPeso())           /// no com peso e aresta com peso
    {
        float idPeso, idAlvoPeso, pesoAresta;
        while(arquivoEntrada >> id >> idPeso >> idAlvo >> idAlvoPeso)
        {
            G->insereAresta(id, idAlvo, pesoAresta);        // insere aresta com peso
            G->getNo(id)->setPeso(idPeso);                  // seta no inicial com peso
            G->getNo(idAlvo)->setPeso(idAlvoPeso);          // seta no alvo com peso
        }
    }
*/


    return G;
}



int main(int argc, char const *argv[])
{

// nome do arquivo de entrada
// nome de arquivo de sa�da
// uma flag 0 ou 1 para indicar grafo orientado ou n�o orientado (nesta ordem)
// uma flag 0 ou 1 para indicar que grafo � ponderado ou n�o ponderado nas arestas (nesta ordem)
// uma flag para indicar que o grafo � ponderado ou n�o ponderado nos n�s (nesta ordem).


//    if (argc !=6)
//    {
//        cout << "ERRO. Formato inv�lido" << endl << "Formato esperado:  ./<nome_do_programa> <arquivo_entrada> <arquivo_saida> <direcionado> <arestaComPeso> <noComPeso>";
//        return 1;
//    }
//
//    string nomeDoPrograma(argv[0]);
//    string nomeArquivoEntrada(argv[1]);

    ifstream arquivoEntrada;
    ofstream arquivoSaida;
    arquivoEntrada.open(argv[1]);
    arquivoSaida.open(argv[2], ios::out | ios::trunc);

    Grafo* G;

    if(arquivoEntrada.is_open())
    {
        //"Formato esperado:  ./<nome_do_programa> <arquivo_entrada> <arquivo_saida> <direcionado> <arestaComPeso> <noComPeso>";
        G = leituraInstancia(arquivoEntrada, atoi(argv[3]), atoi(argv[4]), atoi(argv[5]));
    }
    else
        cout << "Nao e possivel abrir: " << argv[1];

    /// funcao para imprimir o grafo
    G->imprimeGrafo();
    return 0;
}
