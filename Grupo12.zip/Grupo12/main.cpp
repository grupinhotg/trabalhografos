#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <utility>
#include <tuple>
#include <iomanip>
#include <stdlib.h>
#include <chrono>
#include "Grafo.h"
#include "No.h"

using namespace std;

int main()
{
    cout << "////////////////////////////////////////////////////////" << endl;
    cout << "////////// \t Trabalho de Teoria dos Grafos - Grupo 12 \t //////////" << endl;
    cout << "////////// \t Fabricio \t //////////" << endl;
    cout << "////////// \t Joao \t\t //////////" << endl;
    cout << "////////// \t Raphael \t //////////" << endl;
    cout << "////////// \t Teo \t\t //////////" << endl;
    cout << "////////// \t Walkiria \t //////////" << endl;
    cout << "////////////////////////////////////////////////////////" << endl;
    return 0;
}
