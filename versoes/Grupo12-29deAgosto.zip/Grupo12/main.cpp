#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <utility>
#include <tuple>
#include <iomanip>
#include <stdlib.h>
#include <chrono>
#include "Grafo.h"
#include "No.h"

using namespace std;

Grafo* leituraInstancia(ifstream& arquivoEntrada, bool direcionado, bool arestaComPeso, bool noComPeso){

    //Variáveis para auxiliar na criação dos nós no Grafo
    int id;
    int idAlvo;
    int ordem;
    float peso;

    //Pegando a ordem do grafo
    arquivoEntrada >> ordem;

    //Criando objeto grafo
    Grafo* G = new Grafo(ordem, direcionado, arestaComPeso, noComPeso);

    //Leitura de arquivo
    while(arquivoEntrada >> id >> idAlvo >> peso)
    {
        G->insereAresta(id, idAlvo, peso);
    }

    return G;
}



//int main(int argc, char const *argv[])
int main()
{

//  nome do arquivo de entrada
// nome de arquivo de saída
// uma flag 0 ou 1 para indicar grafo orientado ou não orientado (nesta ordem)
// uma flag 0 ou 1 para indicar que grafo é ponderado ou não ponderado nas arestas (nesta ordem)
// uma flag para indicar que o grafo é ponderado ou não ponderado nos nós (nesta ordem).


/*    if (argc !=6)
    {
        cout << "ERRO. Formato inválido" << endl << "Formato esperado:  ./<nome_do_programa> <arquivo_entrada> <arquivo_saida> <direcionado> <arestaComPeso> <noComPeso>";
        return 1;
    }

    string nomeDoPrograma(argv[0]);
    string nomeArquivoEntrada(argv[1]);
*/

    ifstream arquivoEntrada;
//    ofstream arquivoSaida;
    arquivoEntrada.open("entrada");
//    arquivoEntrada.open(argv[1], ios::in);
//    arquivoSaida.open(argv[2], ios::out | ios::trunc);

    Grafo* G;

    if(arquivoEntrada.is_open())
    {
        G = leituraInstancia(arquivoEntrada, 1, 1, 0);
    }
    else
    {
        cout << "Unable to open ";
    }


    G->imprimeGrafo();

    return 0;
}
