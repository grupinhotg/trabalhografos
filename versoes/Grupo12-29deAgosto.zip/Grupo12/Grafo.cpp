#include "Grafo.h"
#include "No.h"
#include "Aresta.h"
#include <iostream>
#include <fstream>
#include <stack>
#include <queue>
#include <list>
#include <math.h>
#include <cstdlib>
#include <ctime>
#include <float.h>
#include <iomanip>

using namespace std;

Grafo::Grafo(int ordem, bool direcionado, bool arestaComPeso, bool noComPeso)
{
    this->ordem = ordem;
    this->direcionado = direcionado;
    this->arestaComPeso = arestaComPeso;
    this->noComPeso = noComPeso;
    this->primeiroNo = this->ultimoNo = nullptr;
    this->numAresta = 0;

    for(int i=1; i<=ordem; i++)
    {
        this->insereNo(i);
    }
}

Grafo::~Grafo()
{
    No *proxNo = this->primeiroNo;
    while(proxNo != nullptr)
    {
        proxNo->removerTodasArestas();
        No *auxNo = proxNo->getProxNo();
        delete proxNo;
        proxNo = auxNo;
    }
}

int Grafo::getOrdem()
{
    return this->ordem;
}

int Grafo::getNumAresta()
{
    return this->numAresta;
}

bool Grafo::getDirecionado()
{
    return this->direcionado;
}

bool Grafo::getArestaComPeso()
{
    return this->arestaComPeso;
}

bool Grafo::getNoComPeso()
{
    return this->noComPeso;
}

No* Grafo::getPrimeiroNo()
{
    return this->primeiroNo;
}

No* Grafo::getUltimoNo()
{
    return this->ultimoNo;
}

void Grafo::insereNo(int id)
{
    No* aux = new No(id); //cria o novo nó
    if(this->primeiroNo == nullptr) // se o grafo estiver vazio, seta o primeiro e o ultimo nó como o novo nó criado
    {
        primeiroNo=aux;
        ultimoNo=aux;
    }
    else    // se o grafo já tiver nós
    {
        ultimoNo->setProxNo(aux);   //seta o próx do ultimo nó para o novo
        ultimoNo = aux;             //seta o ultimo nó como o novo nó criado
    }
}

void Grafo::insereAresta(int id, int idAlvo, float peso)
{
    if(this->direcionado == true)
    {
        No* aux = this->primeiroNo;
        while(aux->getId() != id)
        {
            aux = aux->getProxNo();
        }
        aux->inserirAresta(idAlvo, peso);
    }
    else
    {
        //adiciona uma aresta de id para idAlvo
        No* aux = this->primeiroNo;
        while(aux->getId() != id)
        {
            aux = aux->getProxNo();
        }
        aux->inserirAresta(idAlvo, peso);

        //adiciona uma aresta de idAlvo para id
        aux = this->primeiroNo;
        while(aux->getId() != idAlvo)
        {
            aux = aux->getProxNo();
        }
        aux->inserirAresta(id, peso);

    }
}

void Grafo::removeNo (int id)
{

}

void Grafo::procuraNo (int id)
{

}

No* Grafo::getNo(int id)
{

}

bool Grafo::buscaEmProfundidade (int idInicial, int idAlvo)
{

}

void Grafo::larguraEmProfundidade (ofstream& arquivo_saida)
{

}

Grafo* Grafo::getComplemento()
{

}

Grafo* Grafo::getSubjacente()
{

}

bool Grafo::possuiCircuito()
{

}

bool Grafo::grafoConexo()
{

}

float** Grafo::floydMarshall()
{

}

float* Grafo::dijkstra(int id)
{

}


void Grafo::imprimeGrafo()
{
    No* aux = this->primeiroNo;
    while(aux != nullptr)
    {
        cout << "Nó de ID: " << aux->getId() << endl << "Arestas: ";
        aux->imprimeArestas();
        aux = aux->getProxNo();
        cout << endl;
    }


}
