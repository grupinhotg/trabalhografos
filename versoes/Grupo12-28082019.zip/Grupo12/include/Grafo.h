#ifndef GRAFO_H
#define GRAFO_H


class Grafo
{
    public:
        Grafo();
        virtual ~Grafo();

    protected:

    private:
};

#endif // GRAFO_H
